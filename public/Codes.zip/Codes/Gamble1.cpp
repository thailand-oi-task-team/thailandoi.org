#include <cstdio>
using namespace std;

int i, a, b, V, E;

int main() {
  scanf("%d %d", &V, &E);
  for (i = 0; i < E; i++)
    scanf("%d %d", &a, &b);

  printf("%d\n", V);
  printf("%d", 0);
  for (i = 1; i < V; i++)
    printf(" %d", i);
  printf("\n");

  printf("The value of counter is: %d\n", 0);
  return 0; // will never get TLE
}
